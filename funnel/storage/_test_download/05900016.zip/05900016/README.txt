2013-06-11

This file contains reformatted copies of data retrieved from the USPTO
PAIR site by Google on the date above.  No guarantees are made with
respect to the completeness or accuracy of this data: see
http://portal.uspto.gov/external/portal/pair for official, current,
and complete information.

Each tab on a USPTO PAIR page is converted into a tab-delimited text
file (*.tsv), compatible with many spreadsheet programs.

See http://www.google.com/googlebooks/uspto-patents-pair.html for
further information.
